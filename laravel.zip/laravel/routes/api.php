<?php

use App\Http\Controllers\mobilecontroller;
use Illuminate\Support\Facades\Route;



Route::match(['get', 'post'], '/register', [mobilecontroller::class, 'mobile_data_register']);
Route::match(['get', 'post'], '/view', [mobilecontroller::class, 'mobile_data_view']);
Route::match(['get', 'post'], '/update', [mobilecontroller::class, 'mobile_data_update']);
Route::match(['get', 'post'], '/delete', [mobilecontroller::class, 'mobile_data_delete']);
Route::match(['get', 'post', 'put'], '/search', [mobilecontroller::class, 'mobile_data_search']);
