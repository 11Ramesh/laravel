<?php

namespace App\Http\Controllers;

use App\Models\Form;
use Illuminate\Http\Request;

class mobilecontroller extends Controller
{
    public function mobile_data_register(Request $request)
    {
        $profileImage   = time() . rand(1, 1000) . '.' . $request->profile->extension();
        $request->profile->move(public_path('public/img/user'), $profileImage);
        $formdata = new Form();
        $formdata->profile =  $profileImage;
        $formdata->fname = $request->fname;
        $formdata->lname = $request->lname;
        $formdata->mobile = $request->mobile;
        $formdata->mail = $request->mail;
        $formdata->age = $request->age;
        $formdata->save();
    }

    public function mobile_data_view()
    {
        $form  = Form::all();
        return $form;
    }

    public function mobile_data_update(Request $request)
    {
        $form = Form::find($request->id);
        //Delete the picture from the database
        $picOld = 'public/img/user/' . $form->profile;
        unlink($picOld);

        //updfate function
        $profileImage = time() . rand(1, 1000) . '.' . $request->profile->extension();
        $request->profile->move(public_path('public/img/user'), $profileImage);
        $form->profile = $request->fname;
        $form->fname = $request->fname;
        $form->lname = $request->lname;
        $form->mobile = $request->mobile;
        $form->mail = $request->mail;
        $form->age = $request->age;
        $form->save();
    }

    public function mobile_data_delete(Request $request)
    {

        $form = Form::find($request->id);
        $picOld = 'public/img/user/' . $form->profile;
        unlink($picOld);
        $form->delete();
    }

    public function mobile_data_search(Request $request)
    {
        $query = Form::query();

        // Assuming 'fname' represents the field name in the 'Form' model
        if ($request->has('fname', 'lname')) {
            $query->where('fname', 'like', '%' . $request->fname . '%')->Where('lname', 'like', '%' . $request->lname . '%');
            if (!$request->filled('fname') && !$request->filled('lname')) {
                $results = Form::all();
                return $results;
            }
        } else {
        }

        // Additional conditions can be added based on other fields

        // Execute the query and retrieve the results
        $results = $query->get();

        return $results;
    }
}
